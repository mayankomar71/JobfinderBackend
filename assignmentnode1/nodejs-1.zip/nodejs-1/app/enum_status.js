var status={
    'Pending':0,
    'Rejected':1,
    'Shortlisted':2,
    'Selected':3
}
Object.freeze(status);
module.exports=status;