var role={
    'Admin':1,
    'User':2,
    'Company':3
}
Object.freeze(role);
module.exports=role;