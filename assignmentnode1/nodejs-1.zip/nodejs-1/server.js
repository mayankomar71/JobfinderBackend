const express = require('express');
const bodyParser = require('body-parser');
const app = express();
app.use(bodyParser.urlencoded({ extended: true }))
app.use(bodyParser.json())
const dbConfig = require('./config/database.js');
const mongoose = require('mongoose');

// const http = require("http").Server(app);
// const io = require("socket.io");
// socket = io(http);
// const Chat = require("./app/model/model.js");

// socket.on("connection", (socket) => {
//     console.log("user connected");
  
//     socket.on("disconnect", function() {
//       console.log("user disconnected");
//     });
  
//     //Someone is typing
//     socket.on("typing", (data) => {
//       socket.broadcast.emit("notifyTyping", {
//         user: data.user,
//         message: data.message
//       });
//     });
  
//     //when soemone stops typing
//     socket.on("stopTyping", () => {
//       socket.broadcast.emit("notifyStopTyping");
//     });
  
//     socket.on("chat message", function(msg) {
//       console.log("message: " + msg);
  
//       //broadcast message to everyone in port:5000 except yourself.
//       socket.broadcast.emit("received", { message: msg });
  
//       //save chat to the database
//       mongoose.connect(dbConfig.url, {
//         useNewUrlParser: true
//     }).then((db) => {
//         console.log("Successfully connected to the database");
//         let chatMessage = new Chat({ message: msg, sender: "Anonymous" });
//         chatMessage.save();
//     }).catch(err => {
//         console.log('Could not connect to the database. Exiting now...', err);
//         process.exit();
//     });
//     });
//   });
  
mongoose.connect(dbConfig.url, {
    useNewUrlParser: true
}).then((db) => {
    console.log("Successfully connected to the database");
}).catch(err => {
    console.log('Could not connect to the database. Exiting now...', err);
    process.exit();
});

app.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
  });

app.get('/', (req, res) => {
    res.json({"message": "This is Home Page"});
});

require('./app/routes/routes.js')(app);

app.listen(8081, () => {
    console.log("Server is listening on port 8081");
});